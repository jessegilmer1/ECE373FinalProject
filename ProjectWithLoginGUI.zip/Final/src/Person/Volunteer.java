package Person;

import java.util.ArrayList;
import java.util.Collections;


public class Volunteer extends User{

	public Volunteer() {
		this.setName("No Name");
	}
	

}

